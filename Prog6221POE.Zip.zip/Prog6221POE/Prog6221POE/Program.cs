﻿namespace Prog6221POE
{
    class Program
    {
        public static string recipeName = "";
        public static void Main()
        {
            Recipe recipe = new Recipe();
            Console.WriteLine("Welcome to the recipe app");
            while (true)
            { 
                //create a menu for the user to choose what they would like to do
                Console.WriteLine("Enter 1 to add a recipe\r\n" +
                                "2 to scale the recipe\r\n" +
                                "3 to reset the scaled values back to their original values\r\n" +
                                "4 to clear all data and enter a new recipe\r\n" +
                                "5 to end the program");
            
            string option = Console.ReadLine();
                switch (option)
                {
                case "1":
                    Console.WriteLine("Please enter the recipe name");
                    recipeName = Console.ReadLine();
                    //store this in an array with the recipe details
                    Recipe.getRecipeDetails(Recipe.ingredientNum, recipeName, Recipe.stepNum);
                    Recipe.displayRecipe(recipeName, Recipe.ingredientQuantity);
                    break;
                case "2":
                    Recipe.recipeScaling();
                    break;
                case "3":
                    Recipe.recipeDataReset();
                    break;
                case "4":
                    Recipe.clearData();
                    break;
                case "5":
                    Environment.Exit(0);
                    break;
                }
            } 
        }
        public static int getIngredientNum()
                 {
                     Console.WriteLine("Please enter the number of ingredients you would like to use");
                     int ingredientNo = Convert.ToInt32(Console.ReadLine());
                     return ingredientNo;
                 }
        
                 public static int getStepNum()
                 {
                     Console.WriteLine("Please enter the number of steps in the recipe");
                     int stepNum = Convert.ToInt32(Console.ReadLine());
                     return stepNum;
                 }
         
                 public static string getStepDescriptions(int i)
                 {
                     Console.WriteLine("Please enter a description for each step:");
                     Console.WriteLine("step " + (i + 1));
                     string recipeStepDescription = Console.ReadLine();
                     return recipeStepDescription;
                 }
    }

    class Recipe
    {
        public static int ingredientNum = Program.getIngredientNum();
        public static int stepNum = Program.getStepNum();
        public static string[] ingredientNames = new string[ingredientNum];
        public static double[] ingredientQuantity = new double[ingredientNum];
        public static string[] unitOfMeasurement = new string[ingredientNum];
        public static string[] recipeStepDescription = new string[stepNum];
        public static double[] ingredientQuantityClone = ingredientQuantity.Clone() as double[];

        /*public void recipe(string[] ingredientNames, double[] ingredientQuantity, string[] unitOfMeasurement,
            int stepNum, string[] recipeStepDescription)
            {}*/
        public static void SaveInput()
        {
            double[] ingredientQuantityClone = ingredientQuantity.Clone() as double[];
        }
        public static void getRecipeDetails(int ingredientNo, string recipeName, int stepNum)
        {
            Console.WriteLine("Please state the names of your ingredients:");
            
            for (int i = 0; i < ingredientNo; i++)
            {
                //Console.WriteLine("Ingredient " + (i + 1));
                ingredientNames[i] = Console.ReadLine();
            }

            Console.WriteLine("Please state the unit of measurement of your ingredients and then their quantity:");
            for (int p = 0; p < ingredientNames.Length; p++)
            {
                //getting unit of measurement
                Console.WriteLine("Unit of measurement for: " + ingredientNames[p]);
                Console.WriteLine("Please choose between teaspoon, tablespoon, or cup");
                string choice = Console.ReadLine().ToLower();
                //put an if statement here for error checking and control
                
                
                while ((choice != "teaspoon") && 
                       (choice != "tablespoon") &&
                       (choice != "cup")) 
                    //check logic for this statement, infinite loop present
                {
                    Console.WriteLine("Please choose between teaspoon, tablespoon, or cup only");
                    choice = Console.ReadLine().ToLower();
                }

                //converting unit of measurement to equivalent teaspoon amount
                unitOfMeasurement[p] = choice;
                
                //getting the numerical value for the ingredient amounts
                Console.WriteLine("Quantity of " + ingredientNames[p]);
                ingredientQuantity[p] = Convert.ToDouble(Console.ReadLine());
            }

            //Console.WriteLine("Please enter a description for each step:");
            for (int i = 0; i < Recipe.stepNum; i++)
            {
                //Console.WriteLine("step " + (i + 1));
                int checkLength = recipeStepDescription.Length;
                Console.WriteLine("Length of recipeStepDescription = " + checkLength);
                recipeStepDescription[i] = Program.getStepDescriptions(i);
            }
        }

        public static void displayRecipe(string recipeName, double[] ingredientQuantity2)
        {
            Console.WriteLine("Recipe Name: " + recipeName);
            for (int i = 0; i < ingredientNames.Length; i++)
            {
                Console.WriteLine(ingredientNames[i] + " " + ingredientQuantity2[i] + " " + unitOfMeasurement[i]);
            }

            for (int j = 0; j < stepNum; j++)
            {
                Console.WriteLine(recipeStepDescription[j]);
            }

        }
        
        public static void recipeScaling()
        {
            double tablespoonAmount = 3;//number of teaspoons in a tablespoon
            double cupAmount = 48;//number of teaspoons in cup
            
            
            for (int p = 0; p < ingredientNames.Length; p++)
            {
                //all quantites are converted to teaspoon amount equivalent
                switch (unitOfMeasurement[p])
                {
                    case "tablespoon":
                        ingredientQuantityClone[p] = (ingredientQuantityClone[p] * 3);
                        break;
                    case "cup":
                        ingredientQuantityClone[p] = (ingredientQuantityClone[p] * 48);
                        break;
                }
                
                //switch statement used to present user with options for scaling their recipe
                Console.WriteLine("Please enter a number for the corresponding option");
                Console.WriteLine("1 to scale the recipe by 0.5\r\n" +
                                  "2 to scale the recipe by 2\r\n" +
                                  "3 to scale the recipe by 3\r\n");
                string option = Console.ReadLine();

                //while loop for erroneous user input
                while (option != "1" && option != "2" && option != "3")
                {
                    Console.WriteLine("Please pick between 1, 2 or 3 only");
                    option = Console.ReadLine();
                }
                
                switch (option)
                {
                    case "1":
                        //scale by 0.5
                        for (int i = 0; i < ingredientNames.Length; i++)
                        {
                            ingredientQuantityClone[p] = (ingredientQuantityClone[p] * 0.5);
                        }
                        break;
                    case "2":
                        //scale by 2
                        for (int i = 0; i < ingredientNames.Length; i++)
                        {
                            ingredientQuantityClone[p] = (ingredientQuantityClone[p] * 2);
                        }
                        break;
                    case "3":
                        //scale by 3
                        for (int i = 0; i < ingredientNames.Length; i++)
                        {
                            ingredientQuantityClone[p] = (ingredientQuantityClone[p] * 3);
                        }
                        break;
                }
                
                switch (unitOfMeasurement[p])
                {
                    case "tablespoon":
                        ingredientQuantityClone[p] = (ingredientQuantityClone[p] / 3);
                        break;
                    case "cup":
                        ingredientQuantityClone[p] = (ingredientQuantityClone[p] / 48);
                        break;
                }
            } 
            
            Console.WriteLine("recipe name: "+Program.recipeName);
            Console.WriteLine("Ingredients: ");
            for (int p = 0; p < ingredientNames.Length; p++)
            {
                double scaleValues = ingredientQuantityClone[p];
                double noOfCups = Math.Floor(scaleValues / cupAmount);
                double noOfTableSpoons = Math.Floor((scaleValues - (cupAmount * noOfCups))/tablespoonAmount);
                double noOfTeaspoons = Math.Floor(scaleValues - ((cupAmount * noOfCups) + (tablespoonAmount * noOfTableSpoons)));
                
                Console.WriteLine(ingredientNames[p] + ": " + noOfCups + "cups, " + noOfTableSpoons + "tablespoons, " + 
                                  noOfTeaspoons + "teaspoons");
                Console.WriteLine("");
            }
            
            for (int j = 0; j < stepNum; j++)
            {
                Console.WriteLine(recipeStepDescription[j]);
            }
            Console.WriteLine("Enter any key to return to the main menu");
            Console.ReadKey();
            Program.Main();
        }

        public static void recipeDataReset()
        {
            ingredientQuantityClone = (double[])ingredientQuantity.Clone();

            displayRecipe(Program.recipeName, ingredientQuantityClone);
        }

        public static void clearData()
        {
            Array.Clear(ingredientNames, 0, ingredientNames.Length);
            Array.Clear(ingredientQuantity, 0, ingredientQuantity.Length);
            Array.Clear(ingredientQuantityClone, 0, ingredientQuantityClone.Length);
            Array.Clear(unitOfMeasurement, 0, unitOfMeasurement.Length);
            Array.Clear(recipeStepDescription, 0, recipeStepDescription.Length);
            ingredientNum = 0;
            stepNum = 0;
        }
    } 
}